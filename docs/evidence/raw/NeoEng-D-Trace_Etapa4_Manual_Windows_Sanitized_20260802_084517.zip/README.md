# Pacote sanitizado de evidências manuais da Etapa 4

Os resultados estruturados e logs textuais foram preservados com substituição exclusiva de caminhos absolutos locais por tokens `<EVIDENCE_ROOT>`, `<REPOSITORY_ROOT>` e `<USER_HOME>`.

Os hashes SHA-256 e tamanhos dos arquivos originais estão em `ORIGINAL_FILE_HASHES.json`. Os projetos produzidos não são copiados porque contêm referências absolutas locais; seus hashes e invariantes estruturais estão em `output_projects_manifest.json`.
