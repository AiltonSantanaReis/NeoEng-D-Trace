"""Local evidence collector; never changes gate results or source content."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--label', required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
a.output.mkdir(parents=True, exist_ok=True)
record_path = a.output / (a.label + '.json')
log_path = a.output / (a.label + '.log')
if record_path.exists() or log_path.exists():
    raise SystemExit('Refusing to overwrite evidence')
def git(*args):
    return subprocess.check_output(['git', '-C', str(a.root), *args], text=True).strip()
env = os.environ.copy()
env['QT_QPA_PLATFORM'] = 'offscreen'
env['POETRY_VIRTUALENVS_IN_PROJECT'] = 'true'
env['POETRY_NO_INTERACTION'] = '1'
env['PYTHONIOENCODING'] = 'utf-8'
env['PATH'] = str(a.root / '.venv' / 'Scripts') + os.pathsep + env['PATH']
source_sha = git('rev-parse', 'HEAD')
env['NEOENG_SOURCE_HEAD_SHA'] = source_sha
def redact(text):
    replacements = [(str(a.root), '<project>'), (str(a.output), '<output>'),
                    (os.environ.get('USERPROFILE', ''), '<user>')]
    for value, replacement in replacements:
        if value:
            text = text.replace(value, replacement).replace(value.replace('\\', '/'), replacement)
    return text.replace('\r\n', '\n').replace('\r', '\n')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = git('status', '--porcelain', '--untracked-files=all')
t0 = time.monotonic()
result = subprocess.run(command, cwd=a.root, env=env, stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, encoding='utf-8', errors='replace')
raw = redact(result.stdout).encode('utf-8')
log_path.write_bytes(raw)
record = dict(label=a.label, started_at_utc=started, source_commit=source_sha,
              command=[redact(x) for x in command], exit_code=result.returncode,
              duration_seconds=round(time.monotonic()-t0, 3),
              status_before=redact(before), status_after=redact(git('status', '--porcelain', '--untracked-files=all')),
              log=dict(path=log_path.name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()),
              normalization='UTF-8 LF; project/output/user prefixes redacted; exit status unmodified')
record_path.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(record))
print(redact(result.stdout)[-4000:])
raise SystemExit(result.returncode)
