"""Package current-run evidence without modifying original outputs or snapshots."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--clean', type=Path, required=True)
p.add_argument('--evidence', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--source', required=True)
p.add_argument('--base', required=True)
a = p.parse_args()
if a.output.exists():
    raise SystemExit('Refusing to overwrite an evidence package')
def git(*args):
    return subprocess.check_output(['git', '-C', str(a.repo), *args])
def digest(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode('utf-8')
def normalize(raw):
    if b'\0' in raw:
        return raw
    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError:
        return raw
    for path, replacement in [(a.clean, '<project>'), (a.evidence, '<output>'),
                              (Path(os.environ['USERPROFILE']), '<user>')]:
        for value in [str(path), str(path).replace('\\', '/'), str(path).replace('\\', '\\\\')]:
            text = re.sub(re.escape(value), lambda m: replacement, text, flags=re.I)
    return text.replace('\r\n', '\n').replace('\r', '\n').encode('utf-8')
members = {}
transformations = {}
for path in sorted(a.evidence.rglob('*')):
    if not path.is_file():
        continue
    # Source indexes are retained locally. The package creates its own index
    # for the exact published bytes, including normalized copies of logs.
    if path.name == 'artifact-index.json':
        continue
    raw = path.read_bytes()
    name = 'runs/' + path.relative_to(a.evidence).as_posix()
    members[name] = normalize(raw)
    transformations[name] = {'original': digest(raw), 'packaged': digest(members[name])}
# Receipts must refer to the exact normalized log bytes in this new package.
# Original run files are never rewritten; their digests remain in provenance.
for name in list(members):
    if not name.endswith('.json'):
        continue
    data = json.loads(members[name])
    if isinstance(data, dict) and isinstance(data.get('log'), dict):
        log_name = str(Path(name).parent / data['log']['path']).replace('\\', '/')
        if log_name in members:
            data['original_log_digest'] = data['log']
            data['log'] = {'path': data['log']['path'], **digest(members[log_name])}
            members[name] = json_bytes(data)
            transformations[name]['packaged'] = digest(members[name])
changed = git('diff', '--name-only', a.base, a.source).decode().splitlines()
for revision, label in [(a.base, 'before'), (a.source, 'after')]:
    for name in changed:
        result = subprocess.run(['git','-C',str(a.repo),'show',f'{revision}:{name}'], capture_output=True)
        if result.returncode == 0:
            members[f'source/{label}/{name}'] = result.stdout
members['source/correction.patch'] = git('diff','--binary',a.base,a.source)
for path, name in [
    (a.clean / 'dist/NeoEng-D-Trace/release-manifest.json', 'portable/release-manifest.json'),
    (a.clean / 'build/NeoEng-D-Trace/warn-NeoEng-D-Trace.txt', 'portable/pyinstaller-warnings.txt'),
]:
    raw = path.read_bytes()
    members[name] = normalize(raw)
    transformations[name] = {'original': digest(raw), 'packaged': digest(members[name])}
for name in ['run_gate.py', 'pack_evidence.py']:
    members['reproduction/' + name] = Path(__file__).with_name(name).read_bytes()
roots = ['pen-tool-revalidation-20260903', 'pen-tool-revalidation-20260904-5aec', 'pen-tool-revalidation-20260904-r2']
inventory = []
for name in roots:
    for path in sorted((a.repo / 'docs/evidence/artifacts' / name).rglob('*')):
        if path.is_file():
            inventory.append({'path': path.relative_to(a.repo).as_posix(), **digest(path.read_bytes())})
members['preserved-untracked-inventory.json'] = json_bytes({'classification':'preserved; not evidence for candidate', 'files':inventory})
members['normalization-provenance.json'] = json_bytes(transformations)
members['scope.json'] = json_bytes({'base':a.base, 'tested_source_commit':a.source, 'changed_paths':changed,
    'normalization':'UTF-8 LF, project/output/user prefixes redacted in generated run copies only; originals preserved locally. Source Git blobs unchanged.',
    'excluded_from_package':'Original generated artifact-index.json files remain local; published copies use the new package index.'})
a.output.mkdir(parents=True)
archive = a.output / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as bundle:
    for name, raw in sorted(members.items()):
        bundle.writestr(name, raw)
records = {name: digest(raw) for name, raw in sorted(members.items())}
records[archive.name] = digest(archive.read_bytes())
(a.output / 'artifact-index.json').write_bytes(json_bytes({
    'schema_version':1, 'tested_source_commit':a.source, 'base_commit':a.base,
    'purpose':'P2D-05 typing and tracked-integrity requalification; not UI/CI approval',
    'files': records, 'count':len(records)}))
print(json.dumps({'archive':archive.name, **digest(archive.read_bytes()), 'members':len(members)}))
