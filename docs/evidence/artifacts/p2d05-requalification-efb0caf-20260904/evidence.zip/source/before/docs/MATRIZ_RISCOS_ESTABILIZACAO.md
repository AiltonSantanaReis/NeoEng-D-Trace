# Matriz de Riscos de Estabilização

| ID | Severidade | Risco confirmado | Impacto | Evidência exigida para encerramento |
|---|---|---|---|---|
| R-001 | P0 | Persistência incompleta do projeto | Perda silenciosa de dados | Testes de round-trip completos, migração e falha de gravação |
| R-002 | P0 | Ausência do ciclo Abrir/Salvar completo na UI | Trabalho não persistido | Testes UI e ponta a ponta no Windows |
| R-003 | P0 | Cobertura insuficiente de UI e ferramentas | Regressões não detectadas | Inventário de controles e testes positivos/negativos |
| R-004 | P1 | Undo/Redo incompleto | Edição irreversível ou estado incorreto | Invariante executar/undo/redo por operação |
| R-005 | P1 | Exportação de colisão inconsistente | Falso sucesso e arquivo ausente | Arquivo criado, reaberto e validado |
| R-006 | P1 | CLI pode retornar sucesso sem concluir operação | Automação não confiável | Matriz de argumentos, códigos de saída e outputs |
| R-007 | P1 | Bézier provisório e geometrias inválidas | Forma exportada incorretamente | Testes matemáticos, degenerados e propriedades |
| R-008 | P1 | APIs duplicadas ou parcialmente implementadas | Comportamento contraditório | Contrato único e testes de compatibilidade |
| R-009 | P1 | CI apenas Linux/offscreen | Falhas Windows não detectadas | Job `windows-latest` e testes PySide6 reais |
| R-010 | P1 | Dependências transitivas sem lockfile | Builds não reproduzíveis | Instalação limpa a partir de lockfile |
| R-011 | P2 | Módulos grandes e acoplados ao Qt | Retrabalho e dificuldade de teste | Refatoração posterior protegida por caracterização |
| R-012 | P2 | Limites operacionais e segurança incompletos | Travamento, uso excessivo ou exposição | Testes de limites, caminhos e entradas malformadas |
| R-013 | P1 | Metadados do atlas podem exceder os limites da textura | Recorte incorreto ou falha em engines consumidoras | PNG e JSON reabertos; retângulos contidos; testes unitários e de integração |
| R-014 | P1 | Artefatos Windows não possuem assinatura de código | Aviso de confiança e cadeia de distribuição não autenticada | Declarar `NotSigned`; assinatura é melhoria opcional, não gate de release |
| R-015 | P1 | Formalizações jurídicas e atribuições podem evoluir | Decisões de publicação podem exigir documentação adicional no futuro | Manter o estado real documentado; não é gate técnico ou bloqueio de release |
| R-016 | P2 | Governança da toolchain MSI migrada | Necessidade de preservar a reprodutibilidade do builder | WiX 4.0.6 fixado e provas de reprodutibilidade, instalação, upgrade e reparo |
| R-017 | P1 | Adaptadores nativos Godot/Unity ainda não validados em engines reais | Integração pode divergir em importação, pivô, colisão, overrides ou rollback | Fixtures reais, execução nas engines alvo, dry-run, hashes, CI e evidência por etapa 3 a 10 |
| R-018 | P1 | Escopo parallax pode acoplar o editor a um runtime de engine | Crescimento de escopo, regressão do editor 2D e contrato instável | ADR, documento lateral versionado, preview isolado, limites, benchmark e rollback |
| R-019 | P2 | Paleta de comandos pode divergir dos menus e ignorar estados de ação | Ações indisponíveis ou atalhos inconsistentes | Registro único de `QAction`, testes Qt de habilitação, localização, teclado e regressão |
| R-020 | P1 | Pós-processamento não possui adaptadores nativos de engine | Consumidores podem interpretar preview CPU como suporte de engine | Contrato hash-bound, preview determinístico, fallback explícito, testes, CI e validação pós-merge |
| R-021 | P1 | Runtime de triggers CPU foi integrado sem adaptadores nativos de engine | Consumidores podem interpretar o sidecar CPU como suporte Godot/Unity ou receber eventos fora de ordem | Contrato lateral hash-bound, fixed update, ordenação determinística, replay, cancelamento atômico, limites, auditor fail-closed e declaração explícita de não integração |
| R-022 | P1 | Streaming pode produzir carregamento não determinístico, descarte inseguro ou uso lógico de memória sem limite | Assets ausentes, cache inconsistente, falhas silenciosas ou crescimento não controlado | Sidecar hash-bound, raiz confinada, prioridades estáveis, limite de pendências, cache LRU, cancelamento observável, retry explícito, rollback atômico, auditor fail-closed e CI

### Verificação viva — candidata pré-merge LEGACY-26 — 04/09/2026

Na candidata da PR `#168`, o produto foi validado no SHA `6ede2f6…` e a
documentação no HEAD `ac96825…`, sem merge. O run remoto `33863522514` passou
nos jobs Linux e Windows; C01–C13 estão `PASS` no escopo comprovado. B-04 está
resolvido, os snapshots do runner legado foram preservados e a prova VMware
permanece `PASS_SCOPED` à reconstrução ZIP/patch identificada. O empacotamento
portátil mantém a limitação de proveniência documentada. Tag e release
continuam sem aprovação.

### Verificação histórica pós-merge — PR #166 — 03/09/2026

A PR `#166` foi integrada no merge commit
`8a97ae14e8f84eb86fcacfaefed61f014830fbf9`. O CI pós-merge `33794660766`
passou em Linux (`100779319495`) e Windows (`100779319836`). A execução
confirmou baseline de `3213` arquivos, `130` manifestos, Linux com `1919`
testes aprovados e Windows com runner `189/189`, `1919` testes, zero falhas,
erros ou skips. Cobertura, Stage 4B.5 e o gate formal passaram.

O JUnit Windows confirmou `test_plan_rejects_symlink_escape` e
`test_plan_rejects_symlink_destination` sem falhas ou skips. A reconciliação
formal preservou `11` assinaturas divergentes, `12` ausências e `42`
substitutos, sem alterar snapshots legados. A evidência VMware continua
`PASS_SCOPED` para a reconstrução identificada do ZIP/patch.

**R-009 — ENCERRADO NO ESCOPO DA PR #166.** O risco de CI sem Windows real foi
comprovadamente encerrado no escopo desta etapa; isso não encerra os riscos
globais nem autoriza tag ou release.

### Verificação viva — CI remoto da PR #166 — 03/09/2026

O run remoto `33785352331` foi concluído com Linux
(`100748662139`) e Windows (`100748662510`) em `SUCCESS`, no commit-fonte
`f61ba6108f1c13ffe2c3d9b6b03aca132f3e4fe9`. O checkout do evento
`pull_request` usou o merge sintético
`1eb297dec2faea82b06779778b6463b94a625897`; a cabeça-fonte foi registrada
separadamente e sua ancestralidade foi confirmada.

O runner Windows aceitou `189/189` arquivos e `1919` testes, sem falhas,
erros ou skips. Os testes `test_plan_rejects_symlink_escape` e
`test_plan_rejects_symlink_destination` passaram. O gate formal aceitou a
reconciliação de `11` assinaturas divergentes e `12` ausências, com
`42` substitutos, sem alteração dos snapshots legados. Baseline,
integridade, cobertura e Stage 4B.5 passaram.

No escopo do risco `R-009`, a exigência de um job Windows real foi comprovada
na PR. A prova VMware permanece registrada como validação scoped da reconstrução
ZIP/patch, sem ser promovida a prova do SHA Git. `R-009` está
`ENCERRADO NO ESCOPO DA PR #166`; isso não encerra o plano global nem substitui
revisão humana, merge ou validação pós-merge.

## Estado operacional atual dos riscos

### Verificação viva — correção do timeout Windows — 03/09/2026

O rerun remoto `33767197026` passou no Linux (`100687993442`) e falhou no
Windows (`100687993643`) no shard `44/189`, em
`test_phase4_real_segment_timeout_cancels_and_discards_late_result`: o request
registrou `47,0 ms` quando o contrato exigia pelo menos `50 ms`. A causa foi a
exclusão da latência de fila do `QThreadPool` na medição do worker; a falha foi
preservada no pacote histórico e não classificada como flake sem causa.

No commit `febc85471e5ced519f47626665f5d995e7cf60a9`, o instante inicial passou
a ser capturado na construção do worker. O runner Windows limpo passou em
`189/189` arquivos e `1919` testes, com `0` falhas, `0` erros e `2` skips;
cobertura `92,59%/85,02%`. Baseline, evidência, estática, segurança, Stage 4B.5,
gate formal e empacotamento também passaram.

`R-009` permanece `EM VALIDAÇÃO PRÉ-MERGE`: o novo SHA ainda precisa ser
publicado e validado pelos dois jobs remotos. Symlink continua com prova VMware
scoped à reconstrução ZIP/patch, e merge, tag, release e aprovação permanecem
bloqueados.

### Verificação viva — correção cross-platform do CI — 03/09/2026

A falha inicial do job Linux da PR `#166` foi classificada como defeito de
portabilidade do gate formal: o hash do snapshot era comparado em bytes brutos
e dependia de CRLF/LF. A correção adicionou o digest canônico LF explícito e
teste de regressão, mantendo o digest bruto histórico e os snapshots imutáveis.

A suíte local e os gates de qualidade passaram no SHA `42dcb63`; o runner Windows
passou em `189/189` arquivos. O risco `R-009` não está encerrado: a evidência
remota do SHA corrigido ainda depende do push e de dois jobs Linux/Windows
passarem. Estado: `R-009 EM VALIDAÇÃO PRÉ-MERGE`; merge, tag e release bloqueados.
## Atualização viva — runner Windows e Fase 7 — 03 de setembro de 2026

### Verificação viva — correção cross-platform do CI — 03/09/2026

A falha inicial do job Linux da PR `#166` foi classificada como defeito de
portabilidade do gate formal: o hash do snapshot era comparado em bytes brutos
e dependia de CRLF/LF. A correção adicionou o digest canônico LF explícito e
teste de regressão, mantendo o digest bruto histórico e os snapshots imutáveis.

A suíte local e os gates de qualidade passaram no SHA `42dcb63`; o runner Windows
passou em `189/189` arquivos. O risco `R-009` não está encerrado: a evidência
remota do SHA corrigido ainda depende do push e de dois jobs Linux/Windows
passarem. Estado: `R-009 EM VALIDAÇÃO PRÉ-MERGE`; merge, tag e release bloqueados.

A candidata `8e0ada3fcf1d08058240e5263732d14087b5335c` substituiu o caminho
operacional de cobertura Windows no mesmo processo por shards isolados em
subprocessos, conforme a ADR `docs/ADR_WINDOWS_COVERAGE_SHARD_RUNNER_2026-09-03.md`.
Essa decisão foi motivada por abort/violação de acesso Qt observados sob
cobertura; duas execuções do runner versionado passaram com `189/189` arquivos,
`1918` testes, `0` falhas, `0` erros e `2` skips condicionais.

O risco não está encerrado: o CI remoto ainda não validou o SHA, o baseline
precisa ser regenerado/verificado após o staged final e o symlink do host atual
permanece limitado por `WinError 1314`. A prova VMware anterior é mantida como
evidência scoped da capacidade, sem ser apresentada como prova do SHA atual.

Estado operacional desta revisão: `R-009 EM VALIDAÇÃO PRÉ-MERGE`; merge, tag,
release e aprovação permanecem bloqueados até os critérios da Fase 7.

Atualização corrente de 20 de agosto de 2026: o baseline das Etapas 1–4 é o merge `27b2baffa7701ae5ad90f458c3ba5923a030157f`; a RUNTIME-ETAPA-5 foi integrada no merge `159b1241b012`, com auditoria limpa PASS, artefatos hashados, CI Linux/Windows e validação pós-merge; a RUNTIME-ETAPA-6 foi integrada no merge `46604d336af7867e0dd59f9af6e07e5b39a5827f`, com CI da PR, auditoria, artefatos hashados e validação local pós-merge. R-020 está encerrado no escopo aprovado. R-021 está encerrado no escopo aprovado, permanecendo explícita a ausência de adaptadores nativos Godot/Unity. R-018, R-019 e os snapshots históricos permanecem preservados nos estados registrados abaixo. R-022 está encerrado no escopo aprovado pela PR #125, merge `f0d350ad7b61e2e9bc7865515768f3662804c953`, CI `32430267567` e validação pós-merge reproduzida; streaming GPU, VRAM e integração nativa Godot/Unity permanecem fora do escopo.
### Verificação final da candidata — 03 de setembro de 2026

No commit `55110c03a84a560823586d34e12e514592e6948b`, o runner Windows isolado
passou com `189/189` arquivos, `1918` testes, `0` falhas, `0` erros e `2` skips
condicionais. A cobertura passou com `92,59%` de linhas e `85,02%` de branches.
O histórico legado, as `11` assinaturas divergentes, as `12` ausências e os
snapshots foram preservados; `42` substitutos passaram.

Baseline (3196 files), evidence integrity (125 manifests), estática,
segurança, Stage 4B.5 e empacotamento passaram. O symlink local segue limitado
por `WinError 1314`, e o CI remoto ainda está pendente; a prova VMware continua
scoped. R-009 permanece `EM VALIDAÇÃO PRÉ-MERGE`.

### Verificação do SHA efetivo — 03 de setembro de 2026

A repetição no SHA `33abb5955f41f89f18f2a5fbe42d2ffc36274099` confirmou
`189/189` arquivos, `1918` testes, `0` falhas, `0` erros e
`2` skips, cobertura `92,59%/85,02%`, reconciliação formal das
`11` divergências e `12` ausências, e snapshots preservados.
Estática, segurança, Stage 4B.5, integridade e empacotamento também passaram.
Symlink continua `WinError 1314` no host atual, com prova VMware scoped.
R-009 permanece `EM VALIDAÇÃO PRÉ-MERGE`; CI remoto, merge, tag, release e
aprovação continuam bloqueados.


Snapshot histórico de 15 de agosto de 2026. Atualização vigente de 17 de agosto de 2026: a release oficial `v0.2.0` foi publicada pelo proprietário. `R-014` e `R-015` são riscos aceitos e não bloqueiam release; `R-016` foi revisado e aprovado. A execução dinâmica de Godot/Unity no CI não é requisito; as execuções reais locais reproduzíveis permanecem válidas. Os artefatos sem assinatura continuam declarados, não mascarados. A decisão completa está em `docs/evidence/RECONCILIACAO_GATES_RELEASE_2026-08-17.md`.

Âncoras integradas anteriores permanecem preservadas: Etapa 11 com `877` testes, `90,91%` combinada e `R-003` encerrado; Etapa 12 com merge final `fc81c2ea10e751c15a39627d462ddfff390eeb04`, CI `31688307089` e `R-012` encerrado.

| ID | Estado atual | Evidência/encaminhamento vigente |
|---|---|---|
| R-001 | ENCERRADO NO ESCOPO APROVADO | Persistência v1 integrada; colisões personalizadas e Béziers preservados no round-trip; evidências da Etapa 3 |
| R-002 | ENCERRADO NO ESCOPO APROVADO | Ciclo Abrir/Salvar integrado e validado no Windows; evidências da Etapa 4 |
| R-003 | ENCERRADO NO ESCOPO APROVADO | PR `#45` integrada em `2a38b89e542390b3b4396a88d9a416f3695caadc`; CI pós-merge `31491221322` aceito após auditoria de 877 testes, cobertura 92,77%/85,05%, legado 27/27 e artefatos recursivos sem violações |
| R-004 | ENCERRADO NO ESCOPO APROVADO | PR `#28` fechou o registro; PR técnica `#29`, HEAD `956db473a88641bfdcfbd49ed122479f3fa2c51d`, integrada em `574be9bd0268e70c384903f93f16cf6e73aa57a2`; CI pós-merge `31425585259` aprovou Linux e Windows |
| R-005 | ENCERRADO NO ESCOPO APROVADO | Schema `neoeng-d-trace-collisions` v1 unifica toolbar, painel, metadados genéricos e TXT atômico; PR `#33`, merge `73a128ec44cde17867bbac6a7854ce86a43aba5a`; CI pós-merge `31431739320` aprovou Linux e Windows |
| R-006 | ENCERRADO NO ESCOPO APROVADO | Matriz integral, subprocessos, códigos `0`/`1`/`2` e saídas reais; PR `#36`, merge `99326f2d7ccf7046e401d90830feb8a5d33e9f9a`; CI pós-merge `31437000772` aprovou Linux e Windows |
| R-007 | ENCERRADO NO ESCOPO APROVADO | PR `#38`, merge `fc869250e5067fb7b06b70c7d2dd3c0e1e1ee94e`; CI da PR `31440755594` e pós-merge `31441024001` aprovaram Linux e Windows sem anotações; núcleo geométrico com 95.59% de linhas e 93.29% de branches |
| R-008 | ENCERRADO NO ESCOPO APROVADO | API pública única, wrappers históricos sem implementação própria e regressões; PR `#40`, merge `76dd6b7ca3e7da08fab653d66ae29a33a839baf3`; CI final da PR `31445205968` e pós-merge `31445518755` aprovados em Linux e Windows |
| R-009 | ENCERRADO | CI Linux e Windows estabelecida |
| R-010 | ENCERRADO | Lockfile e instalação reproduzível estabelecidos |
| R-011 | ENCERRADO NO ESCOPO APROVADO | PR `#51`, merge `e7eb4a4c81fa2b46e8b9d5db40562e4ce7021108` e CI pós-merge `31698961646`; refatoração Qt e autosave auditados em Linux/Windows |
| R-012 | ENCERRADO NO ESCOPO APROVADO | PR `#49`, merge `872bf079d228d13d0203d22b844052b1f920e99b` e CI pós-merge `31686321925`; limites de configuração, imagem, projeto, geometria, detecção, broadphase, atlas, GLTF e logs; `928` testes em Linux/Windows; artefatos e legado auditados |
| R-013 | ENCERRADO NO ESCOPO AUDITADO | Limites físico/JSON, transparência de borda e rotação corrigidos; CI pós-merge técnico `31425585259` aprovado |
| R-014 | ACEITO / NÃO BLOQUEANTE | GUI, CLI e MSI retornam `NotSigned`; assinatura não é requisito para validar, gerar, publicar ou comercializar |
| R-015 | ROADMAP / NÃO BLOQUEANTE | NOTICE, política e atribuições registram o estado real; formalizações futuras não são pré-condição de release |
| R-016 | APROVADO | WiX 4.0.6 fixado; dois builds independentes, build oficial, instalação, upgrade, reparo e desinstalação validados; governança revisada |
| R-017 | INTEGRADO PELA PR #84 | A Etapa 10 possui harness fail-closed, fixtures reais e execução real em Godot 4.7.stable e Unity 6000.5.7f1. Dry-run, aplicação, repetição determinística, conflitos manuais, drift de hash, regressões das Etapas 4/6, hashes e privacidade passaram no pacote `docs/evidence/artifacts/native-stage10-2026-08-17/`. A CI não inicializa dinamicamente as engines, o que não é requisito; as execuções reais são evidência local reproduzível. Merge `bca43f399928d69cb81e133e40991b7c011a0c10` e CI pós-merge `32028639637` foram confirmados. |
| R-018 | EM VALIDAÇÃO PRÉ-MERGE | A PR `#99` contém implementação 4A–4B.5, evidências hashadas e execução real Godot/Unity; o risco permanece aberto até os checks obrigatórios e o merge. |
| R-019 | ENCERRADO NO ESCOPO DA ETAPA 3 | PR `#97`, merge `5d4c0829`, CI pós-merge `32125768535`; registry único de QAction, busca, UI, estados, teclado, localização e acessibilidade comprovados |
| R-020 | ENCERRADO NO ESCOPO APROVADO | PR `#121`, merge `159b1241b012`; auditoria, artefatos hashados, CI Linux/Windows e validação pós-merge PASS. Adaptadores nativos, GPU, triggers, streaming e runtime completo permanecem fora do escopo |
| R-021 | ENCERRADO NO ESCOPO APROVADO | PR #123, merge 46604d336af7867e0dd59f9af6e07e5b39a5827f; dispatcher CPU determinístico, contrato hash-bound, fixed update, replay, cancelamento, auditoria, CI e validação pós-merge. Adaptadores nativos Godot/Unity permanecem fora do escopo |
| R-022 | ENCERRADO NO ESCOPO APROVADO | PR #125, merge `f0d350ad7b61e2e9bc7865515768f3662804c953`; CI Linux/Windows `32430267567`; auditoria, baseline, evidências, cobertura e validação pós-merge PASS. Streaming GPU, VRAM e integração nativa Godot/Unity permanecem fora do escopo |

## Auditoria corretiva publicada — 10 de agosto de 2026

A recomendação de encerramento foi reavaliada após o CI pós-merge `#84`,
execução da suíte legada, auditoria de dependências e provas reais de CLI, atlas
e colisões. Os achados e
suas remediações estão em
`docs/evidence/AUDITORIA_RIGOROSA_2026-08-10.md`.

As PRs `#28`/`#29` e o CI pós-merge `31425585259` confirmam a integração da
âncora técnica auditada. `R-004` e `R-013` estão encerrados nos escopos comprovados; os
demais riscos mantêm os estados explícitos da tabela.

## Progresso da Etapa 5

| Pacote | PR | Integração | Evidência principal |
|---|---:|---|---|
| 1 | `#15`/`#16` | integrado | `ETAPA_5_PACOTE_1_COMMAND_MANAGER_CONTRACT.md` e encerramento pós-merge |
| 2A | `#17` | integrado em `5109ba0b03a4d075c73e5183c473b29d94bc7f5c` | relações de objetos e atomicidade |
| 2B | `#18` | integrado em `46f73d47081bcc6e997f494eb0c092c615a8f108` | caminhos de UI sem fallback direto |
| 3A | `#19` | integrado em `830075b354b2fc4f96a8c1516757c1f10cac9833` | gesto do gizmo transacional |
| 3B | `#20` | integrado em `4c9b8a4ad00834b956aedee0871454b9d40439f9` | edição de vértices transacional |
| 3B.1 | `#21` | integrado em `e2e95b332f2647e7e1debd0ff0ed4759676bb992` | remoção do caminho duplicado |
| 4A | `#22` | integrado em `8b59e4fa4dfbe14ad44e85e155073a0843634fd1` | exclusão de objetos transacional |
| 4B | `#23` | integrado em `f8a7e3dce61acd6e9312d70575cdf9eb89297a9a` | movimento e escala de colisão |
| 4C | `#24` | integrado em `0fc089bfc58ff9589f50bb394acd579bc2f71dd3` | camadas e grupos; integração de `LayersPanel` à `MainWindow` comprovada na remediação local de 2026-08-10 |
| 5A | `#25` | integrado em `9235ddc1ceaeddaec2074050eaebdeacaf588e53` | caminhos ativos de criação |
| 5B | `#26` | integrado em `ee38a2f1dc85093e34140ddd087312629b4ecb43` | lotes e geração de colisões reversíveis |
| 5C | `#27` | integrado em `6c4bcb3d945405a4615a4d6551247d1b01ce79f1` | HEAD final `8ce44c238aaea79dafa64b8e1bba3ba5a8a7157e`; 517 testes; CI `#83` e `#84`; validação visual 17/17 |

## Achados registrados na Etapa 2

> **SNAPSHOT HISTÓRICO:** a tabela abaixo registra o que foi observado na Etapa 2. Ela não representa o estado operacional atual e não deve substituir a seção anterior.

| ID | Estado | Evidência consolidada | Encaminhamento |
|---|---|---|---|
| R-001 | CONFIRMADO / ABERTO | Colisão personalizada e Bézier são perdidos; formato sem versão | Etapa 3 |
| R-002 | ABERTO | Persistência interna existe, mas o ciclo Abrir/Salvar não está completo na UI | Etapa 4 |
| R-003 | ABERTO | Caracterização ampliada; cobertura integral de UI permanece pendente | Etapa 11 |
| R-004 | CONFIRMADO / ABERTO | Pacote 1 integrou contrato observável, rollback transacional, pilhas consistentes e estado da UI; comandos por operação, relações completas e mutações diretas permanecem incompletos | Etapa 5 — Pacote 2+ |
| R-005 | ABERTO | Exportação de resultados do painel de colisão permanece parcialmente desconectada | Etapa 6 |
| R-006 | CONFIRMADO / ABERTO | Dois cenários negativos retornam código 0 sem arquivo | Etapa 7 |
| R-007 | CONFIRMADO / ABERTO | Bézier não persiste; métricas geométricas ainda são insuficientes | Etapa 8 |
| R-008 | CONFIRMADO / ABERTO | Duas implementações de LassoTool foram identificadas | Etapa 9 |
| R-011 | ABERTO | Acoplamento ao Qt permanece dívida para refatoração protegida | Etapa 13 |
| R-012 | CONFIRMADO / ABERTO | Schema desconhecido é aceito; tipos incorretos falham sem validação controlada | Etapa 12 |
| R-013 | CONFIRMADO / ABERTO | Retângulo JSON do atlas excede o PNG controlado em 1 pixel | Etapa 10 |

Relatório permanente:
`docs/evidence/ETAPA_2_INVENTARIO_FUNCIONAL_CARACTERIZACAO.md`.

Manifesto estruturado:
`docs/evidence/ETAPA_2_EVIDENCE_MANIFEST.json`.

Pacote bruto preparado para publicação no artefato Windows do CI:
`docs/evidence/raw/NeoEng-D-Trace_Etapa2_Raw_Evidence_Bundle.zip`.

Nenhum risco acima está encerrado por esta etapa.

## Encerramentos registrados

| ID | Estado | Evidência de encerramento |
|---|---|---|
| R-009 | ENCERRADO | Commit `f8f534edd74490f7264ebb153110ae65fce7066c`; workflow `Private validation` `#30` (`30596616841`); jobs Linux `test` (`91050247336`) e Windows `test-windows` (`91050247386`) concluídos com `success`; manifesto íntegro com 207 arquivos antes e depois |
| R-010 | ENCERRADO | Instalação por `poetry sync` no Linux e Windows; lockfile canônico `43aaa1fd290d83f69c55ecf6bdc4abb7f55c170aa3172444f8828af01abeca86`; artefatos Linux `8780354978` e Windows `8780366021` vinculados ao commit validado |
| ETAPA-2 | APROVADA PARA ENCERRAMENTO | PR `#9`; merge `d41093e706d3c8c555f64ef0c15c9ad40219a208`; workflow pós-merge `#36` (`30646258120`); jobs Linux `test` (`91208257924`) e Windows `test-windows` (`91208257772`) com `success`; artefatos `8799557767` e `8799571608`; pacote pós-merge `5356fcfc5bbbe0597f1103e4f063ae7aa5d9474911dba9fc7ae7aac090374069`; riscos R-001 a R-008 e R-011 a R-013 permanecem abertos |
| R-001 | APROVADO PARA ENCERRAMENTO | PR `#11`; HEAD `891fbc9550b5bba9bce041272da1db1f3bc3a7b3`; merge `4a45e9c396da6cd63f44f1cf9792526c305478ec`; workflow da PR `#40` (`30672383923`) e workflow da `main` `#41` (`30672598358`) com Linux e Windows em `success`; `212` testes por sistema; round-trip completo preservando colisões e Béziers; migração legada; escrita atômica; pacote bruto `e082e552c015dd7fd742e8a05a27e454c2db6b63feea052ba162c9e31e2dfe28`; pacote pós-merge `a057fa82620cd0f7a5d8644a615adc65f923a0db36d71caacbf2a6dd41e54396`; encerramento condicionado à integração desta evidência e ao CI final da `main` |
| ETAPA-3-PACOTE-1 | APROVADO PARA ENCERRAMENTO | Persistência v1 integrada por merge commit; correção de path traversal validada; `R-002` e `R-012` permanecem abertos; `R-007` permanece aberto para qualidade geométrica fora deste pacote |

| R-002 | APROVADO PARA ENCERRAMENTO | PR `#13`; HEAD `3469a4a9bfab20fa8cd687e2925a64928e7903d3`; merge `4d663f028c5d501a2da44e3a34077023087df58c`; workflow da PR `#44` (`30741145009`) e workflow da `main` `#45` (`30746901415`) com Linux e Windows em `success`; validação manual GUI v4 com `15/15` checks aprovados, `0` erros automáticos, ciclo Abrir/Salvar, cancelamento, descarte, avisos de imagem, rejeição atômica de JSON corrompido e salvamento no fechamento; encerramento condicionado à integração desta evidência e ao CI final da `main` |
| ETAPA-4 | APROVADA PARA ENCERRAMENTO | Ciclo Abrir/Salvar integrado e validado na UI Windows; `R-004` permanece aberto e é o próximo risco da ordem obrigatória; nenhuma implementação da Etapa 5 iniciada nesta PR documental |

| ETAPA-5-PACOTE-1 | INTEGRADO / APROVADO NO ESCOPO | PR `#15`; HEAD funcional `587a0cc93c3efe6c4e668cb86d624cf79a2479b4`; HEAD mesclado `fb5c72b001e4d8085ec902e383190e04a17dae8c`; merge `46cc0664cd8cfe04a6bd3b89bb6dc56e9681f62a`; workflow pós-merge `#55` (`30769951023`) com Linux `test` (`91555266247`) e Windows `test-windows` (`91555266229`) em `success`; `235` testes locais; cobertura global `53%`; `src/core/commands.py` `60%`; validação manual Windows `9/9`; pacote pós-merge `7e0fc5d64cf0edcdef6ab96cc43d23b7d0d3ce7bfd515ad31db50a4ac9dabe41`; `R-004` permanece aberto para os pacotes seguintes |


| R-004 | ENCERRADO NO ESCOPO APROVADO | PR funcional `#27`; fechamento `#28`; pacote técnico `#29`; âncora `574be9bd0268e70c384903f93f16cf6e73aa57a2`; CI pós-merge `31425585259` com Linux e Windows em `success` |
| R-013 | ENCERRADO NO ESCOPO AUDITADO | Correção de limites físico/JSON, transparência e rotação integrada; CI pós-merge técnico `31425585259` aprovado |
| ETAPA-5 | CONCLUÍDA | Pacotes 1 a 5C, auditoria corretiva e pacote técnico final integrados; CI pós-merge `31425585259` aprovado sem anotações; naquele encerramento, Etapa 6 não iniciada e release não aprovada |
| ETAPA-6 | CONCLUÍDA | Contrato de colisões v1 integrado pela PR `#33`; merge `73a128ec44cde17867bbac6a7854ce86a43aba5a` e CI pós-merge `31431739320` aprovados; `R-005` encerrado; Etapa 7 e release não iniciadas |
| ETAPA-7 | CONCLUÍDA | Contrato integral da CLI integrado pela PR `#36`; merge `99326f2d7ccf7046e401d90830feb8a5d33e9f9a` e CI pós-merge `31437000772` aprovados sem anotações; `R-006` encerrado; Etapa 8 e release não iniciadas |
| ETAPA-8 | CONCLUÍDA | Bézier e geometria integrados pela PR `#38`; merge `fc869250e5067fb7b06b70c7d2dd3c0e1e1ee94e` e CI pós-merge `31441024001` aprovados; `R-007` encerrado |
| ETAPA-9 | CONCLUÍDA | PR `#40`, merge `76dd6b7ca3e7da08fab653d66ae29a33a839baf3`; CI final `31445205968` e pós-merge `31445518755` aprovados; `R-008` encerrado |
| ETAPA-10 | CONCLUÍDA | PR `#42`; CIs `31450335289`, `31451363518` e `31452032479` rejeitados; pré-merge `31457937902` aceito; merge `9b22bdc54b13992658172d4748bfab44f3127c8e`; pós-merge `31463873481` rejeitado; CI corretivo `31464786333`, PR `#43`, merge `f8caec3e7156d308f03046f81d2c89996f959466` e pós-merge `31469610508` aceitos após auditoria |
| ETAPA-13 | CONCLUÍDA | PR funcional `#51`; fechamento `#52`, merge `b4d9390dbd1274c283a3e3985d6d79be47de45d6` e CI pós-merge final `31705652046` auditado; `R-011` encerrado; naquele encerramento, Etapa 14 não iniciada e release não aprovada |
| ETAPA-14 | CONCLUÍDA NO ESCOPO TÉCNICO | PR `#58`, merge `f15193a55d1a5de0c7031f5bab656107302eee1b`; fechamento documental PR `#60`, merge `5b9a435e3910c4192dcf1db36c721e5d6d9069f6`; CI pós-merge `31907063633` auditado; testes, cobertura, legado e evidências reproduzidos; primeira release oficial autorizada pelo proprietário; `R-014` e formalização futura de `R-015` deferidos; `R-016` validado tecnicamente |

## Severidades

- **P0:** risco de perda de dados, corrupção, segurança grave ou impossibilidade de confiar no produto. Bloqueia qualquer release e novas funcionalidades.
- **P1:** falha funcional importante, automação falsa ou regressão relevante. Bloqueia avanço da área afetada.
- **P2:** dívida técnica ou risco moderado com mitigação conhecida. Deve ser planejado e medido.
- **P3:** melhoria sem impacto material imediato. Não pode substituir correções P0/P1.

A matriz deve ser atualizada quando um risco for descoberto, reclassificado ou encerrado. Encerramento exige referência ao commit, testes e relatório de evidência.
